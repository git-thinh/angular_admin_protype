﻿
function controlCtrl($scope) { 

    $scope.sendMsg = function () {
        alert('$scope.message = ' + $scope.moduleID);
    }
}